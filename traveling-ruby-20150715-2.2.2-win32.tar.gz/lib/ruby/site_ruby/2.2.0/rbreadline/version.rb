module RbReadline
  RB_READLINE_VERSION = "0.5.2"
end
